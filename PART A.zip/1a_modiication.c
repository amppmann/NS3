#include<stdio.h>
#include<string.h>
char res[5000];
void sender()
{
 int i,n,len=0;
 char frame[500];
 printf("Enter the number of frames:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
     {
      printf("Enter the frame %d:\n",i+1);
      scanf("%s",frame);
      len+=strlen(frame);
      strcat(res,"\n");
      strcat(res,frame);
      }
printf("\nThe number of bytes transmitted:%d",len);
}

void receiver()
{
 printf("\n\nFrames received:%s\n",res);
}

int main()
{
    sender();
    receiver();
    return 0;
}
